<p align="center">
  <a href="https://www.cloudpanel.io/docs/v2/frontend-area/varnish-cache/wordpress/plugin/" target="_blank">
    <img src="/release/plugin.png?v=0.0.1">
  </a>
</p>