<?php
# Silence is golden (-: